#include "Arduino.h"
#include "Delta.h"
Delta::Delta(int a,int b,int c,int d)
{
 lm1=a;
 lm2=b;
 rm1=c;
 rm2=d;
 trig=11;
 echo=10;
}
Delta::Delta(int a,int b,int c,int d,int t,int e)
{
 lm1=a;
 lm2=b;
 rm1=c;
 rm2=d;
 trig=t;
 echo=e;
}
Delta::Delta(int a,int b)
{
  lm1=2;
  lm2=3;
  rm1=4;
  rm2=5;
  trig=a;
  echo=b;
}
void Delta::start()
{
  Serial.begin(9600);
  Serial.print("Delta's Unicorn is Sucessfully started Running ...");
  pinMode(lm1,OUTPUT);
  pinMode(lm2,OUTPUT);
  pinMode(rm1,OUTPUT);
  pinMode(rm2,OUTPUT);
  pinMode(trig,OUTPUT);
  pinMode(echo,INPUT);
  Serial.println("Pin setup finished. -- Ready -- ");
}
void Delta::fwd()    //forward
{
  digitalWrite(lm1,HIGH);
  digitalWrite(lm2,LOW);
  digitalWrite(rm1,HIGH);
  digitalWrite(rm2,LOW);
  Serial.println("Moving forward");
}
void Delta::bwd()   // backward
{
  digitalWrite(lm1,LOW);
  digitalWrite(lm2,HIGH);
  digitalWrite(rm1,LOW);
  digitalWrite(rm2,HIGH);
  Serial.println("Moving backward ");
}
void Delta::stopper()
{
  digitalWrite(lm1,LOW);
  digitalWrite(lm2,LOW);
  digitalWrite(rm1,LOW);
  digitalWrite(rm2,LOW);
  Serial.println("stopped ");
}
void Delta::left()   // turnleft
{
  digitalWrite(lm1,LOW);
  digitalWrite(lm2,HIGH);
  digitalWrite(rm1,HIGH);
  digitalWrite(rm2,LOW);
  Serial.println("turned left");
  delay(1000);
  digitalWrite(lm1,LOW);
  digitalWrite(lm2,LOW);
  digitalWrite(rm1,LOW);
  digitalWrite(rm2,LOW);
}
void Delta::right()   // turn right
{
  digitalWrite(lm1,HIGH);
  digitalWrite(lm2,LOW);
  digitalWrite(rm1,LOW);
  digitalWrite(rm2,HIGH);
  Serial.println("turned right");
  delay(1000);
  digitalWrite(lm1,LOW);
  digitalWrite(lm2,LOW);
  digitalWrite(rm1,LOW);
  digitalWrite(rm2,LOW);
}
void Delta::SpinL()     // spins left
{
  digitalWrite(lm1,LOW);
  digitalWrite(lm2,HIGH);
  digitalWrite(rm1,HIGH);
  digitalWrite(rm2,LOW);
  Serial.println("Spinning left");
}
void Delta::SpinR()     // spins right
{
  digitalWrite(lm1,HIGH);
  digitalWrite(lm2,LOW);
  digitalWrite(rm1,LOW);
  digitalWrite(rm2,HIGH);
  Serial.println("Spinning right");
}
void Delta::BTcontrol()
{
  if(Serial.available()>0)
  {
    char data = Serial.read();
    if(data == 'a')//forward
    {
      fwd();
    }
    else if(data == 'b') //backward
    {
      bwd();
    }
    else if(data == 'c') //left
    {
      left();
    }
    else if(data == 'd') //right
    {
      right();
    }
    else if(data == 'e') // stop
    {
      stopper();
    }
    else if(data == 'f') //spins left
    {
      SpinL();
    }
    else if(data == 'g') // spins right
    {
      SpinR();
    }
  }
}
void Delta::objavoid()
{
  long duration,distance;
  digitalWrite(trig,HIGH);
  delayMicroseconds(10);
  digitalWrite(trig,LOW);
  duration=pulseIn(echo,HIGH);
  distance=duration/58.2;
  if(distance<30)  //avoid obstacles
  {
    left();
    Serial.println("Object detected!! Avoiding Object");
  }
  else
  {
    fwd();
  }
  delay(0);
}
long Delta::FindObj()  //return object distance
{
  long duration,distance;
  digitalWrite(trig,HIGH);
  delayMicroseconds(10);
  digitalWrite(trig,LOW);
  duration=pulseIn(echo,HIGH);
  distance=duration/58.2;
  Serial.println("Object detected at:  ");
  Serial.println(distance);
  return distance;
}
void Delta::Duo()
{
  if(Serial.available()>0)
  {
    char data = Serial.read();
    if(data == 'a')//forward
    {
      fwd();
    }
    else if(data == 'b') //backward
    {
      bwd();
    }
    else if(data == 'c') //left
    {
      left();
    }
    else if(data == 'd') //right
    {
      right();
    }
    else if(data == 'e') // stop
    {
      stopper();
    }
    else if(data == 'f') //spins left
    {
      SpinL();
    }
    else if(data == 'g') // spins right
    {
      SpinR();
    }
    else if (data == 'i')  // obstacles avoiding
    {
      int n=0;
      while(n<1)
      {
        if (Serial.available()>0)
        {
          char data = Serial.read();
          if(data=='j') // returns to BT pinMode
          {
            n=2;
            Serial.println("Returning to Bluetooth controlled mode");
          }
        }
        else
        {
          objavoid();
        }
      }
    }
  }
}
void UnicornBegin(){
  Serial.begin(9600);
  Serial.println("Initiating Pin Setup");
  pinMode(2,OUTPUT);  //left motor
  pinMode(3,OUTPUT);  //left motor -
  pinMode(4,OUTPUT);  // right motor +
  pinMode(5,OUTPUT);  // right motor -
  pinMode(10,INPUT);  //echo pin
  pinMode(11,OUTPUT); //trig pin
  Serial.println("Pin Setup succesfully completed");
  Serial.println("Unicorn is Running.....");
}
void UnicornBTcontrol(){

  if(Serial.available()>0){
    Serial.println("Bluetooth control enabled");
    char data = Serial.read();
    if(data=='a') // forward
    {
       Unicornfwd();
    }
    else if(data=='b') // backward
    {
      Unicornbwd();
    }
    else if(data=='c') // left
    {
UnicornturnL();
    }
    else if(data=='d') // right
    {
      UnicornturnR();
    }
    else if(data=='e') //stop
    {
      Unicornstop();
    }
    else if(data=='f') // spin left
    {
       UnicornSpinL();
    }
    else if (data=='g') // spin right
    {
      UnicornSpinR();
    }
  }
}
long FindObject()
{
  long duration,distance;
  digitalWrite(11,HIGH);
  delayMicroseconds(10);
  digitalWrite(11,LOW);
  duration=pulseIn(10,HIGH);
  distance=duration/58.2;
  Serial.println("Object detected");
  return distance;

}
void UnicornGo()
{
  long duration,distance;
  digitalWrite(11,HIGH);
  delayMicroseconds(10);
  digitalWrite(11,LOW);
  duration=pulseIn(10,HIGH);
  distance=duration/58.2;
  if(distance<30)  //avoid obstacles
  {
    UnicornturnL();
    Serial.println("Object detected!! Avoiding Object");
  }
  else
  {
    Unicornfwd();
  }
  delay(0);
}
void UnicornDuo(){
  int  m=0;
  Serial.println("Both Bt control and obstacles avoidance are enabled ");
  if(Serial.available()>0){
    char data = Serial.read();
    if(data=='a') // forward
    {
       Unicornfwd();
    }
    else if(data=='b') // backward
    {
      Unicornbwd();
    }
    else if(data=='c') // left
    {
UnicornturnL();
    }
    else if(data=='d') // right
    {
      UnicornturnR();
    }
    else if(data=='e') //stop
    {
      Unicornstop();
    }
    else if(data=='f') // spin left
    {
       UnicornSpinL();
    }
    else if (data=='g') // spin right
    {
      UnicornSpinR();
    }
    else if(data=='i')  // obstacles avoiding
    {
      while(m<1){
        if(Serial.available()>0)
        {
          char data = Serial.read();
          if (data=='j') // returns to BT mode
          {
            m=2;
            Serial.println("Returning to Bluetooth Control mode");
          }
          else
          {
            extern void UnicornGo();
            UnicornGo();
          }
        }
      }
    }
  }
}
void Unicornfwd(){
  digitalWrite(2,HIGH);  // moves forward
  digitalWrite(3,LOW);
  digitalWrite(4,HIGH);
  digitalWrite(5,LOW);
  Serial.println("Moving forward");
}
void Unicornbwd(){
  digitalWrite(2,LOW);  // moves backward
  digitalWrite(3,HIGH);
  digitalWrite(4,LOW);
  digitalWrite(5,HIGH);
  Serial.println("Moving backward");
}
void Unicornstop(){
  digitalWrite(2,LOW);  // STOP
  digitalWrite(3,LOW);
  digitalWrite(4,LOW);
  digitalWrite(5,LOW);
  Serial.println("Stopped moving");
}
void UnicornturnL(){
  digitalWrite(2,LOW);  // turn  left
  digitalWrite(3,HIGH);
  digitalWrite(4,HIGH);
  digitalWrite(5,LOW);
  delay(1000);
  digitalWrite(2,LOW);  // STOP
  digitalWrite(3,LOW);
  digitalWrite(4,LOW);
  digitalWrite(5,LOW);
  Serial.println("Turned left");
}
void UnicornturnR(){
  digitalWrite(2,HIGH);  // turn  right
  digitalWrite(3,LOW);
  digitalWrite(4,LOW);
  digitalWrite(5,HIGH);
  delay(1000);
  digitalWrite(2,LOW);  // STOP
  digitalWrite(3,LOW);
  digitalWrite(4,LOW);
  digitalWrite(5,LOW);
  Serial.println("Turned Right");
}
void UnicornSpinL(){
  digitalWrite(2,LOW);  // spin  left
  digitalWrite(3,HIGH);
  digitalWrite(4,HIGH);
  digitalWrite(5,LOW);
  Serial.println("Spinning left.....");
}
void UnicornSpinR(){
  digitalWrite(2,HIGH);  // spin  right
  digitalWrite(3,LOW);
  digitalWrite(4,LOW);
  digitalWrite(5,HIGH);
  Serial.println("Spinning right....");
}
void HomeAutomation::setOutputPins(int a ,int b, int c,int d)
{
  lightpin=a;
  fanpin=b;
  appliancepin=c;
  lamppin=d;
}
void HomeAutomation::configIO()
{
  // Serial.begin(9600);

}
HomeAutomation::HomeAutomation()
{
    //Serial.begin(9600);
}
HomeAutomation::HomeAutomation(int a,int b,int c,int d)
{
  //Serial.begin(9600);
  lightpin=a;
  fanpin=b;
  appliancepin=c;
  lamppin=d;
}
void HomeAutomation::initiateBTAutomation()
{
  Serial.begin(9600);
  Serial.println("---------Unicorn Initiating functions----------");
  Serial.println("...");
  Serial.println("...");
  Serial.println("...");
  Serial.println("...");
  Serial.println("initiate succesfully completed");
  Serial.println("Delta Library is running...........................................");
  Serial.println("initiating IO config......");
  pinMode(lightpin,OUTPUT);
  pinMode(fanpin,OUTPUT);
  pinMode(appliancepin,OUTPUT);
  pinMode(lamppin,OUTPUT);
  Serial.println("------------------------");
  Serial.println("IO config successful");
}
void HomeAutomation::light()
{
  lightstate=!lightstate;
  digitalWrite(lightpin,lightstate);
  if(lightstate==1)
  {
    Serial.println("Light is turned ON ");
  }
  else
  {
    Serial.println("Light is turned OFF");
  }

  delay(100);
}
void HomeAutomation::appliance()
{
  appliancestate=!appliancestate;
  digitalWrite(appliancepin,appliancestate);
  if(appliancestate==1)
  {
    Serial.println("appliance is turned ON ");
  }
  else
  {
    Serial.println("appliance is turned OFF");
  }

  delay(100);
}
void HomeAutomation::fan()
{
 fanstate=!fanstate;
  digitalWrite(fanpin,fanstate);
  if(fanstate==1)
  {
    Serial.println("fan is turned ON ");
  }
  else
  {
    Serial.println("fan is turned OFF");
  }

  delay(100);
}
void HomeAutomation::lamp()
{
 lampstate=!lampstate;
  digitalWrite(lamppin,lampstate);
  if(lampstate==1)
  {
    Serial.println("lamp is turned ON ");
  }
  else
  {
    Serial.println("lamp is turned OFF");
  }

  delay(100);
}
void HomeAutomation::runBTAutomation()
{
  if(Serial.available()>0)
  {
   char data = Serial.read();
   Serial.print(" BT data fetched is : ");
   Serial.println(data);
   if(data=='a')    // a data from phone via Bluetooth truns on and off the light pin
   {
     light();
     //data='A';
     Serial.end();
     delay(50);
     Serial.begin(9600);
   }
   else if(data=='b') // b data from phone via Bluetooth truns on and off the fan pin
   {
    fan();
    Serial.end();
    delay(50);
    Serial.begin(9600);
    //data='A';
   }
   else if (data == 'c') // c data from phone via Bluetooth truns on and off the appliance pin
   {
    appliance();
    Serial.end();
    delay(50);
    Serial.begin(9600);
    //data='A';
   }
   else if (data =='d') // d data from phone via Bluetooth truns on and off the lamp pin
   {
    lamp();
    Serial.end();
    delay(50);
    Serial.begin(9600);
    //data='A';
   }
   else
   {
    Serial.println(" Recieved BT data is matched , try again ");
    Serial.println(" The Commands valid are :");
    Serial.println("a");
    Serial.println("b");
    Serial.println("c");
    Serial.println("d");
   }
  }
}
