#ifndef Delta_h
#define Delta_h
#include "Arduino.h"
class Delta{
private:
  int lm1;
  int lm2;
  int rm1;
  int rm2;
  int trig;
  int echo;
public:
  Delta(int a,int b,int c, int d);
  Delta(int a,int b,int c, int d,int t,int e);
  Delta(int a,int b);
  void start(); //pinsetup
  void BTcontrol(); // bt control
  void objavoid(); // obstacles avoiding
  long FindObj();  // return object distance
  void Duo();      // both bt controll and obstacles
  void fwd();    // forward
  void bwd();  //backward
  void stopper();  //stops
  void left();  //turn left
  void right();  // utn right
  void SpinL();  //spin left
  void SpinR();   // spin right
};
void UnicornBegin();  // pin setup
void UnicornBTcontrol();  //bt controll
long FindObject();   // return distance of object
void UnicornGo();    // obstacles avoiding
void UnicornDuo();   //Both obstacles avoidance and bt control
void Unicornfwd();
void Unicornbwd();
void Unicornstop();
void UnicornturnL();
void UnicornturnR();
void UnicornSpinL();
void UnicornSpinR();
#endif
